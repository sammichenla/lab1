<!doctype html>
	<html lang="en">
	<head>
		<title> about</title>
		<meta charset="utf-8">
		<link rel="stylesheet" type="text/css" href="library.css">


	</head>
	<body>
		<?php
	include 'header.php';
		?>

		<h1> About the members of our bookclub  </h1>
		<img src="lady.jpg" class="logo">
		<h2> Sarah Owen </h2>
		<p> Sarah Owen runs Chen library with over 100,000 members. Each month the group chooses a new book that deals with themes of race, gender, and justice, and opens up a friendly, literary dialogue on Goodreads.</p>
    <img src="woman.jpg" class="logo">
		<h2> Ivy Leene </h2>
		<p> History lovers, rejoice! Ivy Leene here to help the community of Chen Library fans hanging out on Goodreads.</p>



		<?php
	include 'footer.php';
		?>


	</body>
  </html>
