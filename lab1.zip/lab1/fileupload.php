<?php

session_start();
if (!isset($_SESSION['timer'])){
  header('location:login.php');
}


if (isset($_FILES['fileToUpload'])){
//think about extension and size
$maxsize = 2000000;// maxsize 2 mb
$allowed = array ('jpg','png','jpeg','gif');
//make all file extension lower case and then check
// want to make FILE. JEPG. only JEPG.
$ext = strtolower (substr($_FILES['fileToUpload']['name']),strpos($_FILES['fileToUpload']['name'], '.')+1);

//take file name  and take file and upload them to the server
//upload name to DB
//upload pic to SERVER
$errors = array ();

 //place errors if upload does not work

if(in_array($ext,$allowed)=== false){
$errors[]='THIS IS NOT A ALLOWED EXTENTION';
}
if($_FILES['fileToUpload']['size'] > $maxsize ){
$errors[]='THIS IS TOO BIG FILE';
}

// if there is no errors we will ipload the file
$name = $_FILES['fileToUpload'][name];

move_uploaded_file($_FILES['fileToUpload']['tmp_name'],"image/".$name);
}
 ?>


<!doctype html>


	<html lang="en">
  <meta charset="utf-8">
  <link rel="stylesheet" type="text/css" href="library.css">
	<head>
    <h1> Upload file</h1>
    <p>
  		Here you can upload images by selecting a file then upload
  	</p>
    <body>
<form action="" method="post" enctype="multipart/form-data">
    Select image to upload:
    <input type="file" name="fileToUpload" id="fileToUpload">
    <input type="submit" value="Upload Image" name="submit">
    <p><strong>Note:</strong> only .jpg .jpeg .gif .png format are allowed to a max size of 2 MB</p>
</form>
<?php

if (isset($error)){
if(empty($error)){
echo'<p>' ."Upload!".'</p><br>';
}
else{
foreach ($error as $err){
echo'<p>'.$err.'</p><br>';

}
}
}

 ?>
   </body>
	   </head>
  </html>




 <?php
 include ('footer.php');
 ?>
