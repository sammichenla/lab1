<?php
include 'header.php';
?>

<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
#isset :has this been activated . if the post is set and the post is not empty
#trim is to clear the space if user type in space
$searchauthor = "";
$searchtitle = "";

if(isset($_GET['book_id']))//update the status of the book to reserved
{
$book_id=$_GET['book_id'];
$query ="UPDATE books

         SET reserved=1
				 WHERE book_id=".$book_id;
		$stmt = $db->prepare($query);
		$stmt->execute();
}

if(isset($_POST)&& !empty($_POST)){
	$searchauthor = trim($_POST['author']);
	$searchtitle = trim($_POST['title']);
}

$query = "

SELECT books.book_id, books.title, books.isbn,authors.first_name, authors.last_name,books.reserved
FROM books
JOIN book_author ON books.book_id = book_author.book_id
JOIN authors ON authors.author_id = book_author.author_id";

if ($searchtitle && !$searchauthor) {
    $query = $query . " where books.title like '%" . $searchtitle . "%'";
}
if (!$searchtitle && $searchauthor) {
    $query = $query . " where authors.first_name like '%" . $searchauthor . "%'";
}
if ($searchtitle && $searchauthor) {
    $query = $query . " where books.title like '%" . $searchtitle . "%' and author.first_name like '%" . $searchauthor . "%'"; // unfinished
}

$stmt = $db->prepare($query);
$stmt->bind_result($book_id, $title, $isbn, $first_name, $last_name, $reserved);
$stmt->execute();
?>

<body>
	<div class = "container browse" >
		<div class = "row">
			  <h1> Browse books</h1>
			</div>
			<div class = "row">
				<p class = "textmuted">
					<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt
					</p>
			</div>
		</div>
	<hr>


		<h2> Enter author's name or title of the book</h2>
<form action="" method="post" class= "form-inline">
  Author:<br>
  <input type="text" id="author" name="author" placeholder=" Author of the book" >
  <br>
  Title:<br>
  <input type="text" id= "title" name="title" placeholder=" Name of the book" >
  <br><br>
  <button type="submit" > Submit </button>
</form>

</body>
</html>

<!--create our table with output-->
<?php
  echo "<table>";
  echo"<tr> <td> Title of Book </td> <td> Author Name </td> <td> ISBN </td></tr>";
	while ($stmt->fetch()) {
		if($reserved==0){
		echo"<td>$title</td><td>$first_name $last_name</td><td>$isbn</td>
		<td>
		<form method='get' action=''>
		<button name='book_id' value='".$book_id."' type='submit'> RESERVE BOOK</button>
		</form></td></tr>
";
}



}

echo "</table>";
?>



<p>If you click the "Submit" button, the form-data will be sent to a page called "/action_page.php".</p>
<?php
	include 'footer.php';
?>
