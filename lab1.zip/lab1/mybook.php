<?php
	include ('header.php');

	if(isset($_GET['book_id']))//update the status of the book to NOT reserved
	{
	$book_id=$_GET['book_id'];
	$query ="UPDATE books
	         SET reserved=0
					 WHERE book_id= $book_id";
			$stmt = $db->prepare($query);
			$stmt->execute();
	}
?>

<div class =" container mybook-info">
	<div class ="row">
		<h1> My Books</h1>
</div>
<div class="row">
	<p class="text-muted">
		orem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore
		magna aliqua. Ut enim ad minim veniam, quis
	</p>

</div>
</div>
<hr>

<?php
$query = "

SELECT books.book_id, books.title, books.isbn,authors.first_name, authors.last_name,books.reserved
FROM books
JOIN book_author ON books.book_id = book_author.book_id
JOIN authors ON authors.author_id = book_author.author_id
WHERE books.reserved=1";

$stmt = $db->prepare($query);
$stmt->bind_result($book_id, $title, $isbn, $first_name, $last_name, $reserved);
$stmt->execute();

echo "<table>";
echo"<tr> <td> Title of Book </td> <td> Author Name </td> <td> ISBN </td></tr>";
while ($stmt->fetch()) {
echo"<td>$title</td><td>$first_name $last_name</td><td>$isbn</td>
<td>
<form method='get' action=''>
<button name='book_id'value='".$book_id."'type='submit'> RETURN BOOK</button>
</form></td></tr>";
}
echo "</table>";
 ?>

<?php
include ('footer.php');
?>
