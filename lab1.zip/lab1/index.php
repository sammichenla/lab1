<!doctype html>
	<html lang="en">
	<head>
		<title> Chen Library </title>
		<meta charset="utf-8">
		<link rel="stylesheet" type="text/css" href="library.css">
	</head>
	<body>
		<!-- Menu Section -->
	<?php
include 'header.php';
	?>



	<section id="pagecontent">
		<figure id="topimage">
			<a href="#">
				<img src="books.png" class="bigimage">
			</a>
			<figcaption class="bigtext">
			</figcaption>
		</figure>
		<h1> Welcome to the most popular BOOK CLUB in Sweden. We are here to share. </br>
			Here you can borrow books and enrich your life with knowledge.
		</h1>

		<?php
	include 'footer.php';
		?>




	</body>

	</html>
