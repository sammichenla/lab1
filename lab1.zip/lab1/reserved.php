<!doctype html>
<?php
include ('config.php');

if(isset($_GET['book_id']))//update the status of the book to NOT reserved
{
$book_id=$_GET['book_id'];
$query ="UPDATE books

         SET is_$reserved=0
				 WHERE id= $book_id";
		$stmt = $db->prepare($query);
		$stmt->execute();
}

?>

<html>
<head>
  <meta charset="utf-8">
  <link rel"stylesheet" href="css/library.css">
  <link href="" rel="stylesheet">
</head>
<body class= "site">

  <?php
  include("header.php")
  ?>
  <h1> Your reservation has been made </h1> <br>Thank you </br>

  <?php

$ID = trim($_GET['ID']);
 echo "You are reserving the book with ID:".$ID;
@ $db =new mysqli ($dbserver,$dbuser,$dbpasswd,$dbname );

//check if problem connection
if($db-> connect_error){
echo "Sorry! You are not able to connect, because:" .$db-> connect_error;
exit();
}
$query = "UPDATE book SET reserved = 1 WHERE ID =?";

$statement = $db-> prepare ($query);
$statement -> blind_param ("i", $ ID);
$statement ->execute();

?>

</body>

<?php  include("footer.php")?>

</html>
