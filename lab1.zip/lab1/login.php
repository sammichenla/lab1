<?php
require_once 'config.php';
//creating a LOGIN.php that will either send the user to the hidden page or not allow him/her to enter
session_start();
//1. send username and password combination to the db and ask if there is a user with this combo
// if there is someone, let him LOGIN
// if not let him know that he is not welcome
// DOES CHECK IN DB

//2. send only username and ask the DB to give you the password
//Store the username and password in new variables
//Check if entered password is the same as password in DB
//if it is,let him in; if not, don't
// DOES CHECK IN CODE

if(isset($_POST) && !empty($_POST)){

$myusername = mysqli_real_escape_string($db,$_POST['username']);
$myuserpassword = mysqli_real_escape_string($db,$_POST['password']);

//$myusername = mysqli_real_escape_string($db,$myusername);
//Any code is now banned!
$query="SELECT username,password FROM users WHERE username ='$myusername'";
$stmt = $db-> prepare($query);
echo $query;
//the folowing statement replaces the question mark inside the SQL prepared statement
// this says, it is a string, and the value is whatver is inside the $mysuername
$stmt -> bind_result($dbusername,$dbpassword);
$stmt -> execute();



//check it with while statement

while($stmt-> fetch()){

if($myuserpassword==$dbpassword){
  $_SESSION['timer'] = $myusername;
  header('location:fileupload.php');
}

// is the password that the user entered'admin' same as the password in db'wjedwdwedowjeo'

//we can use something called MD5 hash
//takes a string, and hashes it.
//echo"WELCOME";
}
echo "Wrong password!";

}
 ?>



<!doctype html>
	<html lang="en">
  <meta charset="utf-8">
  <link rel="stylesheet" type="text/css" href="library.css">
	<head>
    <h1> Login</h1>
    <p>
  		Please login with your Username and Password
  	</p>
    <body>
<!-- login stuff refernce from https://www.w3schools.com/howto/howto_css_login_form.asp -->
      <form action="" method="post">
  <div class="container">
    <label for="username"><b>Username</b></label>
    <input type="text" placeholder=" Username" name="username" required>

    <label for="password"><b>Password</b></label>
    <input type="password" placeholder=" Password" name="password" required>

    <button type="submit">Login</button>
  </div>
     </form>
   </body>
	   </head>
  </html>




 <?php
 include ('footer.php');
 ?>
