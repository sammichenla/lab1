<?php
include 'header.php';
$email;
$email = htmlentities($email);
//protects all html entries to be added
//if someone adds h1 tags it will not
//MOSTLY on ALL USER INPUT!!!


?>
<html>
	<body>
    <h1> Contact us</h1>
		<p> Leave us a message, we will get back to you within 24 hr</p>
<!-- refernce from:https://www.w3schools.com/howto/howto_css_contact_form.asp -->
		<div class="container">
		  <form action="action_page.php">

		    <label for="fname">Email</label>
		    <input type="text" id="fname" name="email" placeholder="Enter email">

		    <label for="lname">Subject</label>
		    <input type="text" id="lname" name="lastname" placeholder="Enter subject">

		    <label for="subject">Message</label>
		    <textarea id="subject" name="subject" placeholder="Leave us a message.." style="height:200px"></textarea>

		    <input type="submit" value="Submit">

		  </form>
		</div>

	</body>



	<?php
include 'footer.php';
	?>

  </html>
