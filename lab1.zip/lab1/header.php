<?php
include 'config.php';
?>
 <!doctype html>
 	<html lang="en">
 	<head>
 		<title> browse </title>
 		<meta charset="utf-8">
 		<link rel="stylesheet" type="text/css" href="library.css">

 	</head>

<header>
  <a href="#">
    <img src="booklogo.png" class="logo">
  </a>
  <nav id="mainmenu">
    <ul id="topmenu">
      <li>
        <a class="<?php if ($current_page=='index.php') { echo "active"; } ?>" href="index.php">Home</a>
      </li>

      <li>
        <a class="<?php if ($current_page=='about.php') { echo "active"; } ?>" href="about.php">About us</a>
      </li>
      <li>
        <a class="<?php if ($current_page=='browse.php') { echo "active"; } ?>" href="browse.php">Browse books</a>
      </li>
      <li>
        <a class="<?php if ($current_page=='mybook.php') { echo "active"; } ?>" href="mybook.php">My books</a>
      </li>
      <li>
        <a class="<?php if ($current_page=='contact.php') { echo "active"; } ?>" href="contact.php">Contacts</a>
      </li>
      <li>
        <a class="<?php if ($current_page=='gallery.php') { echo "active"; } ?>" href="gallery.php">Gallery</a>
      </li>
    </ul>
  </nav>
</header>
</html>
