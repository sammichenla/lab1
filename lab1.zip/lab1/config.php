<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);

$current_page = explode('/', $_SERVER['REQUEST_URI']);
$current_page = end($current_page);


$dbserver = 'localhost';
$dbuser = 'root';
$dbpass ='root';
$dbname ='library';

@ $db = new mysqli($dbserver, $dbuser, $dbpass, $dbname);

if ($db->connect_error) {
    echo "could not connect: " . $db->connect_error;
    printf("<br><a href=index.php>Return to home page </a>");
    exit();
}

?>
