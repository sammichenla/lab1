<?php
include 'header.php';
?>
<html>
	<body>
    <h1> Gallery</h1>
		<p> Welcome to our gallery </p>
		<?php
	include 'footer.php';
		?>

	</body>
  </html>
