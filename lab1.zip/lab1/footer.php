<footer>
<p class="copyrightfooter">Copyright 2018 Sammi Chen. All rights reserved.</p>
</footer>
<?php



 ?>
